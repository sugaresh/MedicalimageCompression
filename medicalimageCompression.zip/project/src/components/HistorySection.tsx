import React from 'react';
import { Download, FileType2, Brain, Clock } from 'lucide-react';
import type { CompressionResult } from '../types/compression';

interface HistorySectionProps {
  history: CompressionResult[];
  onViewDetails: (result: CompressionResult) => void;
}

export default function HistorySection({ history, onViewDetails }: HistorySectionProps) {
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };

  const formatSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (history.length === 0) {
    return (
      <div className="text-center py-12">
        <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900">No compression history</h3>
        <p className="mt-2 text-sm text-gray-500">
          Compressed images will appear here
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {history.map((result) => (
        <div
          key={result.id}
          className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow duration-200"
        >
          <div className="p-4">
            <div className="flex items-start gap-4">
              <div className="w-24 h-24 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                <img
                  src={result.compressed}
                  alt="Compressed result"
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2">
                  <FileType2 className="h-4 w-4 text-gray-400" />
                  <span className="text-sm text-gray-500">{result.metadata.type}</span>
                  <span className="text-gray-300">•</span>
                  <span className="text-sm text-gray-500">{result.metadata.dimensions}</span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mt-3">
                  <div>
                    <p className="text-sm text-gray-500">Original Size</p>
                    <p className="font-medium text-gray-900">{formatSize(result.originalSize)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Compressed Size</p>
                    <p className="font-medium text-gray-900">{formatSize(result.compressedSize)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Quality Score</p>
                    <p className="font-medium text-gray-900">{result.analytics.compressionQuality}%</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">ROIs Detected</p>
                    <p className="font-medium text-gray-900">{result.analytics.roiCount}</p>
                  </div>
                </div>
              </div>
              
              <div className="text-right flex-shrink-0">
                <p className="text-sm text-gray-500">{formatDate(result.timestamp)}</p>
                <button
                  onClick={() => onViewDetails(result)}
                  className="mt-2 inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  View Details
                </button>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-50 px-4 py-3 border-t border-gray-200">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <Brain className="h-4 w-4 text-blue-500" />
                <span className="text-gray-600">
                  Processed in {result.analytics.processingTime}s
                </span>
              </div>
              <span className="text-green-600 font-medium">
                {result.analytics.storageReduction}% reduction
              </span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}