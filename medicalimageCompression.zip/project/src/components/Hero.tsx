import React from 'react';
import { ZoomIn } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative bg-white overflow-hidden min-h-screen">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=100&w=2000&h=1600"
          alt="Medical Technology"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-white via-white/95 to-transparent"></div>
      </div>

      <div className="relative">
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16 sm:pt-24 sm:pb-20">
          <div className="max-w-xl">
            <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl">
              <span className="block">AI-Driven Adaptive</span>
              <span className="block text-blue-600">Medical Image Compression</span>
            </h1>
            <p className="mt-3 text-base text-gray-500 sm:mt-5 sm:text-lg md:mt-5 md:text-xl">
              Advanced ROI-based compression technology that preserves diagnostic quality while reducing storage requirements.
            </p>
            <div className="mt-5 sm:mt-8 flex flex-col sm:flex-row sm:gap-4">
              <div className="rounded-md shadow">
                <a href="#demo" className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 md:py-4 md:text-lg md:px-10">
                  Try Demo
                </a>
              </div>
              <div className="mt-3 sm:mt-0">
                <a href="#dataset" className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 md:py-4 md:text-lg md:px-10">
                  View Dataset
                </a>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}