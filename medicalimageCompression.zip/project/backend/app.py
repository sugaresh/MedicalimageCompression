from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import cv2
import numpy as np
from PIL import Image
import io
import os
import pydicom
from skimage.measure import compare_ssim
import tensorflow as tf
from datetime import datetime
import logging

app = Flask(__name__)
CORS(app)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize TensorFlow model for ROI detection
try:
    model = tf.keras.applications.ResNet50(weights='imagenet')
    logger.info("ROI detection model loaded successfully")
except Exception as e:
    logger.error(f"Error loading ROI detection model: {e}")
    model = None

def detect_roi(image):
    """
    Detect regions of interest in medical images
    """
    try:
        # Resize image to model input size
        img = cv2.resize(image, (224, 224))
        img = tf.keras.applications.resnet50.preprocess_input(img)
        img = np.expand_dims(img, axis=0)
        
        # Get model predictions
        predictions = model.predict(img)
        
        # Process predictions to get ROIs
        rois = []
        confidence_threshold = 0.8
        
        # Simulate ROI detection for demo
        # In production, use actual model predictions
        rois.append({
            'x': 50,
            'y': 50,
            'width': 100,
            'height': 100,
            'confidence': 0.95,
            'label': 'Bone Structure'
        })
        
        return rois
    except Exception as e:
        logger.error(f"Error in ROI detection: {e}")
        return []

def compress_image(image, quality=85, roi_areas=None):
    """
    Compress image with ROI-aware compression
    """
    try:
        # Convert to PIL Image
        if isinstance(image, np.ndarray):
            image = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        
        # Create buffer for compressed image
        buffer = io.BytesIO()
        
        # If we have ROIs, apply selective compression
        if roi_areas:
            # Create mask for ROI areas
            mask = Image.new('L', image.size, color=quality)
            for roi in roi_areas:
                # Higher quality for ROI areas
                roi_box = (roi['x'], roi['y'], 
                         roi['x'] + roi['width'], 
                         roi['y'] + roi['height'])
                roi_mask = Image.new('L', image.size, color=95)
                mask.paste(roi_mask, roi_box)
            
            # Apply quality mask
            image.save(buffer, format='JPEG', quality=quality, 
                      optimize=True, quality_layers=[mask])
        else:
            # Standard compression
            image.save(buffer, format='JPEG', quality=quality, optimize=True)
        
        buffer.seek(0)
        return buffer
    except Exception as e:
        logger.error(f"Error in image compression: {e}")
        return None

def calculate_metrics(original, compressed):
    """
    Calculate image quality metrics
    """
    try:
        # Convert images to grayscale for SSIM
        original_gray = cv2.cvtColor(original, cv2.COLOR_BGR2GRAY)
        compressed_gray = cv2.cvtColor(compressed, cv2.COLOR_BGR2GRAY)
        
        # Calculate SSIM
        ssim_score = compare_ssim(original_gray, compressed_gray)
        
        # Calculate compression ratio
        original_size = original.nbytes
        compressed_size = compressed.nbytes
        compression_ratio = original_size / compressed_size
        
        return {
            'ssim': float(ssim_score),
            'compression_ratio': float(compression_ratio),
            'quality_score': float(ssim_score * 100)
        }
    except Exception as e:
        logger.error(f"Error calculating metrics: {e}")
        return None

@app.route('/api/compress', methods=['POST'])
def compress():
    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image provided'}), 400
        
        file = request.files['image']
        start_time = datetime.now()
        
        # Read image
        if file.filename.lower().endswith('.dcm'):
            # Handle DICOM
            dcm = pydicom.dcmread(file)
            image = dcm.pixel_array
            image = cv2.convertScaleAbs(image)
        else:
            # Handle regular images
            image_stream = io.BytesIO(file.read())
            image = cv2.imdecode(np.frombuffer(image_stream.read(), np.uint8), 1)
        
        # Detect ROIs
        rois = detect_roi(image)
        
        # Compress image
        compressed_buffer = compress_image(image, quality=85, roi_areas=rois)
        if not compressed_buffer:
            return jsonify({'error': 'Compression failed'}), 500
        
        # Calculate metrics
        compressed_image = cv2.imdecode(
            np.frombuffer(compressed_buffer.getvalue(), np.uint8), 1
        )
        metrics = calculate_metrics(image, compressed_image)
        
        # Calculate processing time
        processing_time = (datetime.now() - start_time).total_seconds()
        
        # Prepare response
        response = {
            'rois': rois,
            'metrics': metrics,
            'processing_time': processing_time,
            'original_size': len(file.read()),
            'compressed_size': len(compressed_buffer.getvalue())
        }
        
        # Send compressed image and metadata
        return send_file(
            compressed_buffer,
            mimetype='image/jpeg',
            as_attachment=True,
            download_name='compressed.jpg',
            headers={'X-Compression-Metadata': str(response)}
        )
    
    except Exception as e:
        logger.error(f"Error processing request: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'healthy', 'model_loaded': model is not None})

if __name__ == '__main__':
    app.run(debug=True, port=5000)