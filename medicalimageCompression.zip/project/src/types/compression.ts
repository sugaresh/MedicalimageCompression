export interface CompressionResult {
  id: string;
  timestamp: number;
  original: string;
  compressed: string;
  originalSize: number;
  compressedSize: number;
  compressionRatio: number;
  metadata: {
    type: string;
    dimensions: string;
  };
  analytics: {
    roiCount: number;
    compressionQuality: number;
    processingTime: number;
    storageReduction: number;
  };
  rois: Array<{
    x: number;
    y: number;
    width: number;
    height: number;
    confidence: number;
    label: string;
  }>;
}