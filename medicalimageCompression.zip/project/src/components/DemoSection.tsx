import React, { useCallback, useState, useRef } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, AlertCircle, FileType2, CheckCircle2, Brain, ZoomIn, LineChart, Layers, Download } from 'lucide-react';
import type { CompressionResult } from '../types/compression';
import HistorySection from './HistorySection';

const ACCEPTED_TYPES = {
  'image/dicom': ['.dcm', '.dicom'],
  'image/x-dicom': ['.dcm', '.dicom'],
  'application/dicom': ['.dcm', '.dicom'],
  'image/jpeg': ['.jpg', '.jpeg'],
  'image/png': ['.png']
};

const isMedicalImage = (file: File): boolean => {
  if (Object.keys(ACCEPTED_TYPES).slice(0, 3).some(type => file.type === type)) {
    return true;
  }
  const medicalKeywords = ['xray', 'x-ray', 'mri', 'ct', 'ultrasound', 'radiograph', 'scan'];
  const filename = file.name.toLowerCase();
  return medicalKeywords.some(keyword => filename.includes(keyword));
};

const simulateROIDetection = () => {
  // Medical-specific ROI types for internal features
  const roiTypes = [
    'Pulmonary Nodule',
    'Clavicle Fracture',
    'Costophrenic Angle',
    'Hilar Region',
    'Vertebral Alignment',
    'Mediastinal Mass',
    'Pleural Line',
    'Cardiac Border'
  ];

  // Generate 3-5 random ROIs for medical features
  const numROIs = Math.floor(Math.random() * 3) + 3;
  const rois = [];

  // Define the active X-ray area (internal region)
  const xrayArea = {
    x: 150,
    y: 100,
    width: 300,
    height: 400
  };

  // Predefined regions of interest based on common X-ray anatomical areas
  const anatomicalRegions = [
    { x: 250, y: 150, width: 80, height: 100, label: 'Pulmonary Nodule' }, // Upper lung field
    { x: 200, y: 200, width: 120, height: 90, label: 'Hilar Region' }, // Central chest
    { x: 180, y: 300, width: 100, height: 70, label: 'Cardiac Border' }, // Heart region
    { x: 270, y: 250, width: 60, height: 80, label: 'Pleural Line' }, // Lateral chest wall
    { x: 220, y: 180, width: 70, height: 90, label: 'Mediastinal Mass' } // Mediastinum
  ];

  // Mix predefined and random ROIs
  for (let i = 0; i < numROIs; i++) {
    let roi;
    
    if (i < anatomicalRegions.length && Math.random() > 0.3) {
      // Use predefined anatomical region 70% of the time
      roi = { ...anatomicalRegions[i] };
    } else {
      // Generate random ROI within X-ray area
      const width = Math.floor(Math.random() * 40) + 40; // 40-80px
      const height = Math.floor(Math.random() * 40) + 40; // 40-80px

      // Ensure ROI stays within X-ray area
      const x = Math.floor(Math.random() * (xrayArea.width - width)) + xrayArea.x;
      const y = Math.floor(Math.random() * (xrayArea.height - height)) + xrayArea.y;

      roi = {
        x,
        y,
        width,
        height,
        label: roiTypes[Math.floor(Math.random() * roiTypes.length)]
      };
    }

    // Add confidence score
    roi.confidence = (Math.random() * 0.15) + 0.80; // 80-95% confidence

    rois.push(roi);
  }

  return rois;
};

export default function DemoSection() {
  const [preview, setPreview] = useState<CompressionResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'compression' | 'roi' | 'analytics' | 'batch' | 'history'>('compression');
  const [history, setHistory] = useState<CompressionResult[]>([]);
  const roiCanvasRef = useRef<HTMLCanvasElement>(null);

  const simulateCompression = async (file: File): Promise<CompressionResult> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const originalSize = file.size;
        const compressedSize = originalSize * 0.4;
        const compressionRatio = originalSize / compressedSize;

        const img = new Image();
        img.onload = () => {
          resolve({
            id: Date.now().toString(),
            timestamp: Date.now(),
            original: e.target?.result as string,
            compressed: e.target?.result as string,
            originalSize,
            compressedSize,
            compressionRatio,
            metadata: {
              type: file.type || 'Unknown',
              dimensions: `${img.width}x${img.height}px`
            },
            analytics: {
              roiCount: 2,
              compressionQuality: 92,
              processingTime: 1.2,
              storageReduction: 60
            },
            rois: simulateROIDetection()
          });
        };
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    setError(null);
    if (acceptedFiles.length === 0) return;

    const file = acceptedFiles[0];
    
    if (!isMedicalImage(file)) {
      setError('Please upload a valid medical image (DICOM, X-ray, MRI, CT scan, etc.)');
      return;
    }

    setLoading(true);
    try {
      const result = await simulateCompression(file);
      setPreview(result);
      
      // Add to history
      const historyEntry: CompressionResult = {
        id: Date.now().toString(),
        timestamp: Date.now(),
        ...result
      };
      setHistory(prev => [historyEntry, ...prev].slice(0, 10)); // Keep last 10 items
    } catch (error) {
      console.error('Error processing image:', error);
      setError('Error processing image. Please try again.');
    }
    setLoading(false);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: ACCEPTED_TYPES,
    maxFiles: 1,
    maxSize: 50 * 1024 * 1024
  });

  const formatSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleDownload = useCallback(() => {
    if (!preview) return;

    const link = document.createElement('a');
    link.href = preview.compressed;
    
    const originalExt = preview.metadata.type.split('/')[1] || 'jpg';
    const filename = `compressed_medical_image_${preview.analytics.compressionQuality}q.${originalExt}`;
    
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }, [preview]);

  const handleDownloadROI = useCallback(() => {
    if (!preview || !roiCanvasRef.current) return;

    const canvas = roiCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;

      ctx.drawImage(img, 0, 0);

      preview.rois.forEach(roi => {
        ctx.strokeStyle = '#3B82F6';
        ctx.lineWidth = 2;
        ctx.strokeRect(roi.x, roi.y, roi.width, roi.height);

        ctx.fillStyle = '#3B82F6';
        const label = `${roi.label} (${(roi.confidence * 100).toFixed(1)}%)`;
        const labelMetrics = ctx.measureText(label);
        ctx.fillRect(roi.x, roi.y - 24, labelMetrics.width + 16, 20);

        ctx.fillStyle = '#FFFFFF';
        ctx.font = '12px Arial';
        ctx.fillText(label, roi.x + 8, roi.y - 10);
      });

      const dataUrl = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.href = dataUrl;
      link.download = 'medical_image_roi_analysis.png';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };
    img.src = preview.original;
  }, [preview]);

  const renderTabContent = () => {
    if (!preview && activeTab !== 'history') return null;

    switch (activeTab) {
      case 'history':
        return (
          <HistorySection
            history={history}
            onViewDetails={(result) => {
              setPreview(result);
              setActiveTab('compression');
            }}
          />
        );
      case 'compression':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-8">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Brain className="h-5 w-5 text-blue-600" />
                  <p className="text-sm font-medium text-gray-900">Original Image</p>
                </div>
                <div className="relative aspect-square bg-white rounded-lg overflow-hidden shadow-sm">
                  <img
                    src={preview.original}
                    alt="Original"
                    className="object-contain w-full h-full"
                  />
                  <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded">
                    {formatSize(preview.originalSize)}
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-green-600" />
                    <p className="text-sm font-medium text-gray-900">Compressed Result</p>
                  </div>
                  <button
                    onClick={handleDownload}
                    className="inline-flex items-center px-3 py-1.5 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    <Download className="h-4 w-4 mr-1.5" />
                    Download
                  </button>
                </div>
                <div className="relative aspect-square bg-white rounded-lg overflow-hidden shadow-sm">
                  <img
                    src={preview.compressed}
                    alt="Compressed"
                    className="object-contain w-full h-full"
                  />
                  <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded">
                    {formatSize(preview.compressedSize)}
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-blue-50 rounded-xl p-6">
              <h4 className="text-lg font-medium text-blue-900 mb-4">Compression Analysis</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-sm text-blue-600">Quality Score</p>
                  <p className="text-2xl font-bold text-blue-900">{preview.analytics.compressionQuality}%</p>
                </div>
                <div>
                  <p className="text-sm text-blue-600">Size Reduction</p>
                  <p className="text-2xl font-bold text-green-600">{preview.analytics.storageReduction}%</p>
                </div>
                <div>
                  <p className="text-sm text-blue-600">Processing Time</p>
                  <p className="text-2xl font-bold text-blue-900">{preview.analytics.processingTime}s</p>
                </div>
                <div>
                  <p className="text-sm text-blue-600">Compression Ratio</p>
                  <p className="text-2xl font-bold text-blue-900">{preview.compressionRatio.toFixed(2)}x</p>
                </div>
              </div>
            </div>
          </div>
        );

      case 'roi':
        return (
          <div className="space-y-6">
            <div className="relative aspect-video bg-white rounded-lg overflow-hidden shadow-sm">
              <img
                src={preview.original}
                alt="ROI Detection"
                className="object-contain w-full h-full"
              />
              {preview.rois.map((roi, index) => (
                <div
                  key={index}
                  className="absolute border-2 border-blue-500 bg-blue-500 bg-opacity-10"
                  style={{
                    left: `${roi.x}px`,
                    top: `${roi.y}px`,
                    width: `${roi.width}px`,
                    height: `${roi.height}px`
                  }}
                >
                  <div className="absolute -top-6 left-0 bg-blue-500 text-white text-xs px-2 py-1 rounded">
                    {roi.label} ({(roi.confidence * 100).toFixed(1)}%)
                  </div>
                </div>
              ))}
              <canvas ref={roiCanvasRef} className="hidden" />
            </div>
            <div className="bg-blue-50 rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="text-lg font-medium text-blue-900">ROI Detection Results</h4>
                <button
                  onClick={handleDownloadROI}
                  className="inline-flex items-center px-3 py-1.5 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  <Download className="h-4 w-4 mr-1.5" />
                  Download Analysis
                </button>
              </div>
              <div className="space-y-4">
                {preview.rois.map((roi, index) => (
                  <div key={index} className="flex items-center justify-between bg-white p-4 rounded-lg">
                    <div className="flex items-center gap-3">
                      <ZoomIn className="h-5 w-5 text-blue-600" />
                      <div>
                        <p className="font-medium text-gray-900">{roi.label}</p>
                        <p className="text-sm text-gray-500">Position: ({roi.x}, {roi.y})</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-blue-600">{(roi.confidence * 100).toFixed(1)}%</p>
                      <p className="text-sm text-gray-500">Confidence</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'analytics':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <div className="flex items-center gap-2 mb-4">
                  <LineChart className="h-5 w-5 text-blue-600" />
                  <h4 className="text-lg font-medium text-gray-900">Performance Metrics</h4>
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Compression Quality</span>
                      <span className="font-medium text-gray-900">{preview.analytics.compressionQuality}%</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div
                        className="h-full bg-blue-600 rounded-full"
                        style={{ width: `${preview.analytics.compressionQuality}%` }}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Storage Reduction</span>
                      <span className="font-medium text-gray-900">{preview.analytics.storageReduction}%</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div
                        className="h-full bg-green-600 rounded-full"
                        style={{ width: `${preview.analytics.storageReduction}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <div className="flex items-center gap-2 mb-4">
                  <Brain className="h-5 w-5 text-blue-600" />
                  <h4 className="text-lg font-medium text-gray-900">Processing Stats</h4>
                </div>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Processing Time</p>
                      <p className="text-2xl font-semibold text-gray-900">{preview.analytics.processingTime}s</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">ROIs Detected</p>
                      <p className="text-2xl font-semibold text-gray-900">{preview.analytics.roiCount}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'batch':
        return (
          <div className="space-y-6">
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <div className="flex items-center gap-2 mb-6">
                <Layers className="h-5 w-5 text-blue-600" />
                <h4 className="text-lg font-medium text-gray-900">Batch Processing Queue</h4>
              </div>
              <div className="space-y-4">
                <div className="relative p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <FileType2 className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">Current Image</p>
                        <p className="text-sm text-gray-500">{preview.metadata.type} • {preview.metadata.dimensions}</p>
                      </div>
                    </div>
                    <span className="text-green-600 font-medium">Processed</span>
                  </div>
                  <div className="mt-3">
                    <div className="h-2 bg-gray-100 rounded-full">
                      <div className="h-full bg-green-600 rounded-full w-full" />
                    </div>
                  </div>
                </div>
                <div className="opacity-50">
                  <div className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 bg-gray-100 rounded-lg flex items-center justify-center">
                          <Upload className="h-5 w-5 text-gray-400" />
                        </div>
                        <p className="text-gray-400">Drop more files to process in batch</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div id="demo" className="py-16 bg-gradient-to-b from-blue-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center mb-12">
          <h2 className="text-base text-blue-600 font-semibold tracking-wide uppercase">Interactive Demo</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            Experience AI-Powered Compression
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            Upload your medical images and witness the power of our advanced compression technology.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            {!preview && activeTab !== 'history' && (
              <div
                {...getRootProps()}
                className={`border-3 border-dashed rounded-xl p-12 text-center cursor-pointer transition-all duration-200 ${
                  isDragActive 
                    ? 'border-blue-500 bg-blue-50 scale-102'
                    : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50'
                }`}
              >
                <input {...getInputProps()} />
                <div className="mx-auto w-16 h-16 mb-4 bg-blue-100 rounded-full flex items-center justify-center">
                  <Upload className="h-8 w-8 text-blue-600" />
                </div>
                <p className="text-xl font-medium text-gray-700">
                  {isDragActive ? 'Drop your medical image here' : 'Upload your medical image'}
                </p>
                <p className="mt-2 text-sm text-gray-500">
                  Supported formats: DICOM, X-ray images, MRI scans, CT scans (JPEG/PNG)
                </p>
                <div className="mt-4 flex items-center justify-center gap-2 text-sm text-gray-500">
                  <FileType2 className="h-4 w-4" />
                  <span>Maximum file size: 50MB</span>
                </div>
              </div>
            )}

            {error && (
              <div className="mt-4 p-4 bg-red-50 rounded-lg flex items-center gap-2 text-red-700">
                <AlertCircle className="h-5 w-5 flex-shrink-0" />
                <p>{error}</p>
              </div>
            )}

            {loading && (
              <div className="mt-8 text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
                <p className="mt-4 text-gray-600">Analyzing and compressing image...</p>
              </div>
            )}

            {(preview || activeTab === 'history') && !loading && (
              <div className="space-y-6">
                <div className="border-b border-gray-200">
                  <nav className="-mb-px flex space-x-8">
                    {[
                      { id: 'compression', label: 'Compression', icon: Brain },
                      { id: 'roi', label: 'ROI Detection', icon: ZoomIn },
                      { id: 'analytics', label: 'Analytics', icon: LineChart },
                      { id: 'batch', label: 'Batch Processing', icon: Layers },
                      { id: 'history', label: 'History', icon: FileType2 }
                    ].map((tab) => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id as typeof activeTab)}
                        className={`
                          group inline-flex items-center py-4 px-1 border-b-2 font-medium text-sm
                          ${activeTab === tab.id
                            ? 'border-blue-500 text-blue-600'
                            : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                          }
                        `}
                      >
                        <tab.icon className={`
                          h-5 w-5 mr-2
                          ${activeTab === tab.id ? 'text-blue-500' : 'text-gray-400 group-hover:text-gray-500'}
                        `} />
                        {tab.label}
                      </button>
                    ))}
                  </nav>
                </div>

                <div className="mt-6">
                  {renderTabContent()}
                </div>

                <div className="mt-6 flex justify-end">
                  <button
                    onClick={() => {
                      setPreview(null);
                      setActiveTab('compression');
                    }}
                    className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Process Another Image
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}