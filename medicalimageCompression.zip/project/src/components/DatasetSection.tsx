import React from 'react';
import { Database, Download, ExternalLink } from 'lucide-react';

const datasets = [
  {
    name: 'TCIA Collections',
    description: 'The Cancer Imaging Archive - Extensive collection of medical images of cancer',
    images: '129M+',
    format: 'DICOM',
    size: '45+ TB',
    url: 'https://www.cancerimagingarchive.net/collections/',
    categories: ['CT', 'MRI', 'PET', 'X-Ray']
  },
  {
    name: 'MedPix®',
    description: 'NIH Medical Image Database with peer-reviewed teaching cases',
    images: '12,000+',
    format: 'JPEG/DICOM',
    size: '8.3 GB',
    url: 'https://medpix.nlm.nih.gov/home',
    categories: ['Radiology', 'Pathology', 'Ophthalmology']
  },
  {
    name: 'OASIS Brain Dataset',
    description: 'Open Access Series of Imaging Studies - Brain MRI scans',
    images: '2,168',
    format: 'NIFTI/DICOM',
    size: '12.4 GB',
    url: 'https://www.oasis-brains.org/',
    categories: ['MRI', 'Neuroimaging']
  },
  {
    name: 'ChestX-ray14',
    description: 'NIH Chest X-ray Dataset of Common Thorax Diseases',
    images: '112,120',
    format: 'PNG',
    size: '45.6 GB',
    url: 'https://nihcc.app.box.com/v/ChestXray-NIHCC',
    categories: ['X-Ray', 'Chest']
  }
];

export default function DatasetSection() {
  return (
    <div id="dataset" className="py-16 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center mb-12">
          <h2 className="text-base text-blue-600 font-semibold tracking-wide uppercase">Dataset</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            Comprehensive Medical Image Collections
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            Access verified medical imaging datasets for research and development.
          </p>
        </div>

        <div className="mt-10">
          <div className="space-y-6">
            {datasets.map((dataset) => (
              <div key={dataset.name} className="bg-white overflow-hidden shadow-lg rounded-2xl transition-all duration-200 hover:shadow-xl">
                <div className="px-6 py-8">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center">
                        <div className="flex-shrink-0">
                          <Database className="h-6 w-6 text-blue-600" />
                        </div>
                        <div className="ml-4">
                          <h3 className="text-xl font-semibold text-gray-900">{dataset.name}</h3>
                          <p className="mt-1 text-base text-gray-500">{dataset.description}</p>
                        </div>
                      </div>

                      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
                        <div>
                          <p className="text-sm font-medium text-gray-500">Images</p>
                          <p className="mt-1 text-lg font-semibold text-gray-900">{dataset.images}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-500">Format</p>
                          <p className="mt-1 text-lg font-semibold text-gray-900">{dataset.format}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-500">Size</p>
                          <p className="mt-1 text-lg font-semibold text-gray-900">{dataset.size}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-500">Categories</p>
                          <div className="mt-1 flex flex-wrap gap-1">
                            {dataset.categories.map((category) => (
                              <span
                                key={category}
                                className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800"
                              >
                                {category}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 flex justify-end gap-4">
                    <a
                      href={dataset.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center px-4 py-2 border border-blue-600 rounded-md shadow-sm text-sm font-medium text-blue-600 bg-white hover:bg-blue-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Visit Website
                    </a>
                    <a
                      href={dataset.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Access Dataset
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 bg-blue-50 rounded-2xl p-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Dataset Usage Guidelines</h3>
            <ul className="space-y-3 text-gray-600">
              <li className="flex items-start">
                <span className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-blue-600 mt-2"></span>
                <p className="ml-3">Please review and comply with each dataset's specific licensing terms and conditions.</p>
              </li>
              <li className="flex items-start">
                <span className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-blue-600 mt-2"></span>
                <p className="ml-3">Cite the dataset appropriately in your research or publications.</p>
              </li>
              <li className="flex items-start">
                <span className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-blue-600 mt-2"></span>
                <p className="ml-3">Some datasets may require registration or institutional approval for access.</p>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}