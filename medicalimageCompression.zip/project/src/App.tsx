import React from 'react';
import { Brain, Database, Image as ImageIcon, LineChart, Upload, ZoomIn } from 'lucide-react';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import DatasetSection from './components/DatasetSection';
import DemoSection from './components/DemoSection';
import Footer from './components/Footer';
import ChatBot from './components/ChatBot';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      <Header />
      <Hero />
      <Features />
      <DemoSection />
      <DatasetSection />
      <Footer />
      <ChatBot />
    </div>
  );
}

export default App;