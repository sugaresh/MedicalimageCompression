import React from 'react';
import { Brain, AlertTriangle, Ruler, LineChart, Clock, Activity } from 'lucide-react';
import type { AIAnalysis } from '../types/analysis';

interface AIAnalysisPanelProps {
  analysis: AIAnalysis;
  isLoading: boolean;
}

export default function AIAnalysisPanel({ analysis, isLoading }: AIAnalysisPanelProps) {
  if (isLoading) {
    return (
      <div className="p-6 bg-white rounded-lg shadow-lg">
        <div className="flex items-center justify-center space-x-2">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-500"></div>
          <span className="text-gray-600">Analyzing image with AI...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Diagnosis Section */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <div className="flex items-center gap-3 mb-4">
          <Brain className="h-6 w-6 text-blue-600" />
          <h3 className="text-xl font-semibold text-gray-900">AI Diagnosis</h3>
          <span className={`ml-auto px-3 py-1 rounded-full text-sm font-medium
            ${analysis.diagnosis.severity === 'high' ? 'bg-red-100 text-red-800' :
              analysis.diagnosis.severity === 'moderate' ? 'bg-yellow-100 text-yellow-800' :
                'bg-green-100 text-green-800'}`}>
            {analysis.diagnosis.severity.charAt(0).toUpperCase() + analysis.diagnosis.severity.slice(1)} Severity
          </span>
        </div>
        
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-600">Condition</span>
              <span className="font-medium text-gray-900">{analysis.diagnosis.condition}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-blue-600 h-2 rounded-full"
                style={{ width: `${analysis.diagnosis.confidence * 100}%` }}
              />
            </div>
            <p className="text-sm text-gray-500 mt-1">
              {(analysis.diagnosis.confidence * 100).toFixed(1)}% confidence
            </p>
          </div>

          <div>
            <h4 className="font-medium text-gray-900 mb-2">Recommendations</h4>
            <ul className="space-y-2">
              {analysis.diagnosis.recommendations.map((rec, index) => (
                <li key={index} className="flex items-start gap-2">
                  <Activity className="h-5 w-5 text-blue-500 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-600">{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Abnormalities Section */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <div className="flex items-center gap-3 mb-4">
          <AlertTriangle className="h-6 w-6 text-yellow-600" />
          <h3 className="text-xl font-semibold text-gray-900">Detected Abnormalities</h3>
        </div>

        <div className="space-y-4">
          {analysis.abnormalities.map((abnormality, index) => (
            <div key={index} className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium text-gray-900">{abnormality.type}</span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium
                  ${abnormality.risk_level === 'high' ? 'bg-red-100 text-red-800' :
                    abnormality.risk_level === 'moderate' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'}`}>
                  {abnormality.risk_level} risk
                </span>
              </div>
              <p className="text-sm text-gray-600 mb-2">Location: {abnormality.location}</p>
              <div className="w-full bg-gray-200 rounded-full h-1.5">
                <div
                  className="bg-yellow-500 h-1.5 rounded-full"
                  style={{ width: `${abnormality.confidence * 100}%` }}
                />
              </div>
              <p className="text-xs text-gray-500 mt-1">
                {(abnormality.confidence * 100).toFixed(1)}% confidence
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Measurements Section */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <div className="flex items-center gap-3 mb-4">
          <Ruler className="h-6 w-6 text-green-600" />
          <h3 className="text-xl font-semibold text-gray-900">Measurements</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-medium text-gray-900 mb-3">Dimensions</h4>
            <div className="space-y-3">
              {analysis.measurements.dimensions.map((dim, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-gray-600">{dim.name}</span>
                  <span className="font-medium text-gray-900">
                    {dim.value} {dim.unit}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-medium text-gray-900 mb-3">Density Measurements</h4>
            <div className="space-y-3">
              {analysis.measurements.densities.map((density, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-gray-600">{density.region}</span>
                  <span className="font-medium text-gray-900">
                    {density.value} {density.unit}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Historical Comparison */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <div className="flex items-center gap-3 mb-4">
          <Clock className="h-6 w-6 text-purple-600" />
          <h3 className="text-xl font-semibold text-gray-900">Historical Comparison</h3>
        </div>

        <div className="space-y-4">
          {analysis.comparison.previous_studies.map((study, index) => (
            <div key={index} className="border-l-4 border-purple-200 pl-4">
              <p className="text-sm text-gray-500 mb-2">{study.date}</p>
              <div className="space-y-2">
                {study.changes.map((change, changeIndex) => (
                  <div key={changeIndex} className="flex items-start gap-2">
                    <span className={`inline-block w-2 h-2 rounded-full mt-1.5
                      ${change.significance === 'improved' ? 'bg-green-500' :
                        change.significance === 'stable' ? 'bg-blue-500' :
                          'bg-red-500'}`}
                    />
                    <div>
                      <p className="text-sm font-medium text-gray-900">{change.type}</p>
                      <p className="text-sm text-gray-600">{change.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}