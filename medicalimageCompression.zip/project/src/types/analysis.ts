export interface AIAnalysis {
  diagnosis: {
    condition: string;
    confidence: number;
    severity: 'low' | 'moderate' | 'high';
    recommendations: string[];
  };
  abnormalities: Array<{
    type: string;
    location: string;
    confidence: number;
    risk_level: 'low' | 'moderate' | 'high';
  }>;
  measurements: {
    dimensions: Array<{
      name: string;
      value: number;
      unit: string;
    }>;
    densities: Array<{
      region: string;
      value: number;
      unit: string;
    }>;
  };
  comparison: {
    previous_studies: Array<{
      date: string;
      changes: Array<{
        type: string;
        description: string;
        significance: 'improved' | 'stable' | 'worsened';
      }>;
    }>;
  };
}

export interface AnalysisResult extends AIAnalysis {
  id: string;
  timestamp: number;
  imageUrl: string;
  processingTime: number;
  modelVersion: string;
  confidenceScore: number;
}