import React, { useState } from 'react';
import { MessageCircle, X, MinusCircle } from 'lucide-react';

interface Message {
  text: string;
  isBot: boolean;
}

const INITIAL_MESSAGE = "Hi! I can help explain medical imaging terms and navigate the site. What would you like to know?";

const FAQ_RESPONSES: Record<string, string> = {
  'psnr': 'Peak Signal-to-Noise Ratio (PSNR) measures image quality after compression. Higher values indicate better quality, typically above 30dB is considered good.',
  'roi': 'Region of Interest (ROI) refers to specific areas in medical images that contain important diagnostic information. Our system automatically detects and preserves these regions during compression.',
  'compression': 'We use hybrid compression that combines traditional methods with AI to maintain diagnostic quality while reducing file size. ROIs are preserved at higher quality than non-critical areas.',
  'quality': 'Our compression maintains diagnostic quality by: 1) Detecting ROIs, 2) Applying selective compression, and 3) Validating results against medical standards.',
  'format': 'We support DICOM, JPEG, and PNG formats. DICOM files maintain their metadata during compression.',
  'security': 'All images are processed locally in your browser. No data is sent to external servers, ensuring privacy and security.',
};

export default function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { text: INITIAL_MESSAGE, isBot: true }
  ]);
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage = { text: input, isBot: false };
    setMessages(prev => [...prev, userMessage]);

    // Generate response
    const lowercaseInput = input.toLowerCase();
    let response = "I'm not sure about that. Try asking about PSNR, ROI, compression, quality, supported formats, or security.";

    // Check for navigation requests
    if (lowercaseInput.includes('demo') || lowercaseInput.includes('try')) {
      response = "You can try our demo by scrolling down to the 'Demo' section or clicking the 'Try Demo' button at the top.";
    } else if (lowercaseInput.includes('dataset')) {
      response = "Our dataset section shows various medical image collections you can use. Scroll down or click 'View Dataset' to explore.";
    } else {
      // Check FAQ responses
      for (const [keyword, answer] of Object.entries(FAQ_RESPONSES)) {
        if (lowercaseInput.includes(keyword)) {
          response = answer;
          break;
        }
      }
    }

    setMessages(prev => [...prev, { text: response, isBot: true }]);
    setInput('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 bg-blue-600 text-white rounded-full p-3 shadow-lg hover:bg-blue-700 transition-colors"
      >
        <MessageCircle className="h-6 w-6" />
      </button>
    );
  }

  return (
    <div
      className={`fixed bottom-4 right-4 bg-white rounded-lg shadow-xl border border-gray-200 transition-all duration-200 ${
        isMinimized ? 'w-auto h-auto' : 'w-80 h-96'
      }`}
    >
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        <div className="flex items-center gap-2">
          <MessageCircle className="h-5 w-5 text-blue-600" />
          <h3 className="font-medium text-gray-900">Help Assistant</h3>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="text-gray-500 hover:text-gray-700"
          >
            <MinusCircle className="h-5 w-5" />
          </button>
          <button
            onClick={() => setIsOpen(false)}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </div>

      {!isMinimized && (
        <>
          <div className="p-4 h-64 overflow-y-auto space-y-4">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`rounded-lg px-4 py-2 max-w-[80%] ${
                    message.isBot
                      ? 'bg-gray-100 text-gray-900'
                      : 'bg-blue-600 text-white'
                  }`}
                >
                  {message.text}
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 border-t border-gray-200">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask about PSNR, ROI, etc..."
                className="flex-1 rounded-md border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                onClick={handleSend}
                className="px-3 py-2 bg-blue-600 text-white rounded-md text-sm hover:bg-blue-700"
              >
                Send
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}